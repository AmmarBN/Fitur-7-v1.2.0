</p>

<p align="center">

<a href="#"><img title="Whatsapp-Bot" src="https://img.shields.io/badge/Fitur 7 V1.2.0-green?colorA=%23ff0000&colorB=%23017e40&style=for-the-badge"></a>

</p>






## Fitur-7-v1.2.0

> **use wisely**

<p align="center">
<a href="https://github.com/mhankbarbar"><img title="Author" src="https://img.shields.io/badge/Author-AmmarBN-red.svg?style=for-the-badge&logo=github"></a>
</p>

<a href="https://github.com/mhankbarbar/termux-wabot/watchers"><img title="Watching" src="https://img.shields.io/github/watchers/Nurutomo/wabot-aq?label=Watchers&color=blue&style=flat-square"></a>
<a href="https://github.com/mhankbarbar/followers"><img title="Followers" src="https://img.shields.io/github/followers/mhankbarbar?color=blue&style=flat-square"></a>
<a href="https://github.com/mhankbarbar/termux-wabot/stargazers/"><img title="Stars" src="https://img.shields.io/github/stars/AmmarBN/Fitur-7-v1.2.0?color=red&style=flat-square"></a>
<a href="https://github.com/mhankbarbar/termux-wabot/network/members"><img title="Forks" src="https://img.shields.io/github/forks/Nurutomo/wabot-aq?color=red&style=flat-square"></a>
![](https://img.shields.io/badge/python-2-blue.svg)
![Lines of code](https://img.shields.io/badge/From%20Hello%20World%20I%27ve%20Written-4%20Thousand%20lines%20of%20code-blue)
## Instalation Project
```shell script
-pkg update && pkg upgrade
```

```shell script
-pkg install git
```

```shell script
-pkg install bash
```

```shell script
-pkg install python && pkg install python2
```

```shell script
-pkg install python3
```

```shell script
-pip install requests
```

```shell script
-pkg install neofetch
```

## Start Project
```shell script
-git clone https://github.com/AmmarBN/Fitur-7-v1.2.0
```

```shell script
-cd Fitur-7-v1.2.0
```

```shell script
-python2 start.py
```

## Login
```shell script
Username : LordAmmar
```

```shell script
Password : subscribe
```

```shell script
Nomor : You Phone Number
```

## Matematika Login

> **Username : AmmarBN**

> **Password : subscribe**




## Creator/Owner
```shell script
##~>AmmarBN
```

```shell script
##~>SpeedX
```

```shell script
##~>Nurutomo
```

```shell script
##~>Ariffb
```

## Note
> **it is forbidden to recode this script, if you are cought recode script, you will get spam from the script creators, so if you want to recoderecode, have permission first**

<p align="center">

<a href="#"><img title="Whatsapp-Bot" src="https://img.shields.io/badge/Author Whatsapp-green?colorA=%23ff0000&colorB=%23017e40&style=for-the-badge"></a>

</p>





* [`Click Here`](https://wa.me/6287708773367)



> **This is script generator number, namely ©AmmarBN**

## Features

> **•CCTV IP**

> **•Spam SMS**

> **•Symbol Font**

> **•18+**

> **•Kinemaster**

> **•Matematika**

> **•Report**

> **•Art Menu**

> **•Donasi**

> **•install Hollywood & cmatrix**

> **•Bot whatsapp Number**

> **•Google Translate**

## Contributors

---------

<a href="https://github.com/AmmarBN"><img src="https://github.com/AmmarBN.png" width="100" height="100"></a>  [![Nurutomo](https://github.com/Nurutomo.png?size=100)](https://github.com/Nurutomo)  [![Ariffb](https://github.com/ariffb25.png?size=100)](https://github.com/ariffb25)  [![SpeedX](https://github.com/TheSpeedX.png?size=100)](https://github.com/TheSpeedX)

----|----|----|---- 




















## Done
THX To ©AmmarBN

<p align="center">
<a href="https://github.com/mhankbarbar"><img title="Author" src="https://img.shields.io/badge/Author-AmmarBN-red.svg?style=for-the-badge&logo=github"></a>
</p>
