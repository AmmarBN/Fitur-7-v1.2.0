import os,sys,time
print ("Loading.....")
time.sleep(5)
print ("""╭─ *「 RULES BOT」*
├❒ DILARANG TOXIC
├❒ DILARANG SPAM
├❒ DILARANG KIRIM VIRTEX
├❒ DILARANG KIRIM 18+ 
├❒ DILARANG TELPON / VC
├❒ DILARANG CULIK BOT
├❒ DILARANG PROMOSI
├❒ BOT TIDAK MENERIMA SAVE KONTAK
├❏ Jika Bot Tidak Respon:Tanda Ada Kendala Jaringan/Kuota Bot Abis:v
├❏ Makanya Donasi Kuota Gak Gratis:v
├❏ [🗣️] Wifi Lah Bang:v
├❏ [👤] Belum Ada Duit Ajg:v
│
├❏ KALO MELANGGAR AKAN LANGSUNG DIBAN/DI BLOKIR TANPA TOLERANSI SEDIKIT PUN
├❏ MEMULAI BOT KETIK *#menu*
│
└─ *「 RULES BOT」*""")
print ("Memuat Link....")
time.sleep(5)
os.system("xdg-open https://wa.me/6287708773367")
print ("Done")
