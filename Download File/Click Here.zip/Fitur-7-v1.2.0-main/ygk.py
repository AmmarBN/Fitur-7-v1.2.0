import os,sys,time,requests
os.system("clear")
# mengetik otomatis
def mengetik(z):
    for e in z + "\n":
        sys.stdout.write(e)
        sys.stdout.flush()
        time.sleep(0.001)

def lagi():
       f = raw_input("Porno Lagi?? (y/t):")
       if f == "y":
           os.system("python2 ygk.py")
       elif f == "t":
              os.system("bash main.sh")
              sys.exit()

print ("Device Kamu")
os.system("neofetch")
print ("Copyrivht By AmmarBN")
print ("""\033[1;0m\033[1;41m( B ) ( o ) ( k ) ( e ) ( p )\033[1;0m""")

time.sleep(5)
print ("\033[1;93m==================================")
print "(1) porno1"
print "(2) porno2"
print "(3) porno3"
print "(4) porno4"
print "(5) porno5"
print "(6) porno6"
print "(7) porno7"
print "(8) porno8"
print "(9) porno9"
print "(10) porno10"
print "(11) porno11"
print ("===========================================")
print
pilih = input("Options : ")
if pilih == 1:
        print ("Memuat Link.....")
        time.sleep(10)
        os.system("xdg-open https://www.mediafire.com/file/h2nygxbyb6n9cyo/VID-20210107-WA1468.mp4/file")
        lagi()

if pilih == 2:
        print ("Memuat Link.....")
        time.sleep(10)
        os.system("xdg-open https://www.mediafire.com/file/pk8hozohzdc076c/VID-20210107-WA1466.mp4/file")
        lagi()

if pilih == 3:
        print ("Memuat Link.....")
        time.sleep(10)
        os.system("xdg-open https://www.mediafire.com/file/pk8hozohzdc076c/VID-20210107-WA1466.mp4/file")
        lagi()

if pilih == 4:
        print ("Memuat Link.....")
        time.sleep(10)
        os.system("xdg-open https://www.mediafire.com/file/arpphhxsv94ak0r/VID-20210107-WA1462.mp4/file")
        lagi()

if pilih == 5:
        print ("Memuat Link.....")
        time.sleep(10)
        os.system("xdg-open https://www.mediafire.com/file/us3f4j62emftbrf/VID-20210107-WA1463.mp4/file")
        lagi()


if pilih == 6:
        print ("Memuat Link.....")
        time.sleep(10)
        os.system("xdg-open https://www.mediafire.com/file/v4033tkl16hgf2b/VID-20210107-WA1459.mp4/file")
        lagi()

if pilih == 7:
        print ("Memuat Link.....")
        time.sleep(10)
        os.system("xdg-open https://www.mediafire.com/file/3scnim6d1x4b8ie/VID-20210107-WA1461.mp4/file")
        lagi()

if pilih == 8:
        print ("Memuat Link.....")
        time.sleep(10)
        os.system("xdg-open https://www.mediafire.com/file/dx9tklonu0eq36w/VID-20210107-WA1464.mp4/file")
        lagi()

if pilih == 9:
        print ("Memuat Link.....")
        time.sleep(10)
        os.system("xdg-open https://www.mediafire.com/file/snwja297dv4zvtl/VID-20210107-WA0036.mp4/file")
        lagi()

if pilih == 10:
        print ("Memuat Link.....")
        time.sleep(10)
        os.system("xdg-open https://www.mediafire.com/file/60dqek0mqhyt6rn/VID-20210107-WA1530.mp4/file")
        lagi()

if pilih == 11:
        print ("Memuat Link.....")
        time.sleep(10)
        os.system("xdg-open https://www.mediafire.com/file/ni2mcdknb6zn50t/VID-20210107-WA1532.mp4/file")
        lagi()
