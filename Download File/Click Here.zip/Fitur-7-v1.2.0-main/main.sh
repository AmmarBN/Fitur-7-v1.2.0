#!bin/bash/sh
clear
blue="\033[34;1m"
green="\033[32;1m" 
purple="\033[35;1m"
cyan="\033[36;1m"
red="\033[31;1m"
echo "Info Device Kamu"
sleep 2
neofetch
echo
toilet -f big -F gay Fitur-7
echo "v2.0.0"
echo "Creator : AmmarBN"
echo -e $green"Jumlah Database :" $purple "512" $blue "User"
echo '
      [Menu]
[1], CCTV IP
[2], SpamSMS
[3], symbolfont
[4], 18+
[5], Kinemaster
[6], Matematika
[7], Report
[8], Art Menu
[9], Donasi
[10], Install Hollywood & cmatrix
[11], Bot Whatsapp Number
[12], Google Translate
'
echo
read -p "Masukkan Pilihan Kamu : " pil
if [[ $pil == 1 ]]; then
     python2 sadap.py
fi
if [[ $pil == 2 ]]; then
     git clone https://github.com/AmmarBN/smS
     cd smS
     python smS.py
fi
if [[ $pil == 3 ]]; then
     echo "Loading....."
     sleep 3
     echo '➀➁➂➃➄➅➆➇➈➉·¨…¦┅┆➊➋➌➍➎➏➐➑➒➓αɐβɔ卐™©®¿¡½⅓⅔¼¾⅛⅜⅝⅞℅№⇨
     ❝❞℃∃┈ℑ∧∠∨∩⊂⊃∪⊥∀ΞΓəɘεɟɥиɯηℵ℘๏ɹʁℜяʌʍλℓч∞ΣΠ⌥⌘¢€£¥ⒶⒷⒸⒹⒺⒻⒼⒽⒾⒿⓀⓁⓂⓃⓄ
     ⓅⓆⓇⓈⓉⓊⓋⓌⓍⓎⓏ╧╨╤╥╙ⓐⓑⓒⓓⓔⓕⓖⓗⓘⓙⓚⓛⓜⓝⓞⓟⓠⓡⓢⓤⓥⓦⓧⓨⓩ╒╓╫╪┘ツ♋웃유Σ⊗♒☠☮☯♠Ω♤♣♧
     ♥♡♦♢♔♕♚♛★☆✮✯☄☾☽♏╘┌╬☼☀☁☂☃☻☺۞۩♬✄✂✆✉✦✧∞♂♀☿←→↘❤❥❦❧™®©✗✘⊗♒▢╛┐─┼▲△▼▽◆◇○◎●
     ◯Δ◕◔ʊϟღ回₪✓✔✕✖☢☣☤☥☦☧☨☩☪☫☬☭└┴┬├┊╱╲╳¯–—≡჻░▒▓▤▥▦▧▨▩█▌▐▀▄◠◡╭╮╯╰│┤╡╢╖╰╕╣║╝╜╞╟╚╔╩╦╠═
     {｡^◕‿◕^｡}(◕^^◕)✖✗✘♒♬✄✂✆✉✦✧♱♰♂♀☿❤❥❦❧™®©♡♦♢♔♕♚♛★☆✮✯☄☾☽☼☀☁☂☃☻☺☹☮۞۩εїз☎☏¢☚☛☜☝☞☟
     ✍✌☢☣☠☮☯♠♤♣♧♥♨๑❀✿ψ♆☪☭♪♩♫ʊϟღツ回₪卐©®¿¡½⅓♪♩♭♪の☆→あ￡❤｡◕‿◕｡✎✟ஐ≈๑۩۩....۩۩๑๑۩۞۩๑✲❈➹~.~◕‿-｡☀❣☂☁】【┱┲✚✪✣✤✥✦❉❥❦❧❃※₪℗♘♗'
     echo "done"
exit
fi
if [[ $pil == 4 ]]; then
     python2 ygk.py
fi
if [[ $pil == 5 ]]; then
     git clone https://github.com/AmmarBN/BAGI-BAGI-KM
     cd BAGI-BAGI-KM
     python2 KM.py
fi
if [[ $pil == 6 ]]; then
     git clone https://github.com/AmmarBN/MATEMATIKA
     cd MATEMATIKA
     python2 matematika.py
fi
if [[ $pil == 7 ]]; then
     python2 report.py
fi

if [[ $pil == 8 ]]; then
     bash art.sh
fi

if [[ $pil == 9 ]]; then
     bash donasi.sh
fi

if [[ $pil == 10 ]]; then
     pkg install hollywood
     pkg install cmatrix
echo "Untuk menjalankan Hollywood ketik : hollywood"
echo "Untuk Menjalankan Cmatrix Ketik : cmatrix"
exit
fi

if [[ $pil == 11 ]]; then
     python bot.py
fi

if [[ $pil == 12 ]]; then
     git clone https://github.com/AmmarBN/GOOGLE-TRANSLATE
     cd GOOGLE-TRANSLATE
     python translate.py
fi

if [[ $pil == ""  ]]; then
echo "Input Salah!"
sleep 6
     bash main.sh
fi
